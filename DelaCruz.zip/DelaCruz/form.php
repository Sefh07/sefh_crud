<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATTENDANCE</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <link rel="stylesheet" href="form1.css">
</head>

<body>
    <div class="form-container">
        <h2>COMPANY ATTENDANCE CHECKER</h2>
        <form id="ordersForm">
            <div>
                <label for="Fname">First Name</label>
                <input type="text" name="Fname" id="Fname" required>
            </div>
            <div>
                <label for="Lname">Last Name</label>
                <input type="text" name="Lname" id="Lname" required>
            </div>
            <div>
                <label for="employeeID">Employee ID</label>
                <input type="text" name="employeeID" id="employeeID" required>
            </div>
            <div>
                <label for="position">Position</label>
                <input type="text" name="position" id="position" required>
            </div>
            <div class="form-buttons">
                <input type="submit" value="Submit">
                <a href="index.php" class="btn-check-list">ATTENDANCE LISTS</a>
                <input type="reset" value="Clear">
            </div>
        </form>
    </div>

    <script>
        $(document).ready(function() {
            $('#ordersForm').submit(function(e) {
                e.preventDefault();

                let Fname = $('#Fname').val().trim();
                let Lname = $('#Lname').val().trim();
                let employeeID = $('#employeeID').val().trim();
                let position = $('#position').val().trim();

                if (!Fname || !Lname || !employeeID || !position) {
                    alert("All required fields must be filled!");
                    return;
                }

                const frm = new FormData();
                frm.append("method", "saveCustomers");
                frm.append("Fname", Fname);
                frm.append("Lname", Lname);
                frm.append("employeeID", employeeID);
                frm.append("position", position);

                const $submitBtn = $(this).find('input[type="submit"]');
                const originalBtnText = $submitBtn.val();
                $submitBtn.prop('disabled', true).val('Submitting...');


                axios.post("handler.php", frm)
                    .then(function(response) {
                        if (response.data && response.data.ret == 1) {
                            alert("Orders saved successfully!");
                            $('#ordersForm')[0].reset();
                        } else {
                            alert("Error saving order: " + (response.data.msg || "Please check your input or try again later."));
                        }
                    })
                    .catch(function(error) {
                        console.error("Request failed:", error);
                        if (error.response) {
                            console.error("Server Error Data:", error.response.data);
                            console.error("Server Error Status:", error.response.status);
                            alert(`Server Error ${error.response.status}: ${error.response.data.msg || 'Failed to process request.'}`);
                        } else if (error.request) {
                            console.error("No response received:", error.request);
                            alert("Could not connect to the server. Please check your network connection.");
                        } else {
                            console.error("Error setting up request:", error.message);
                            alert("An error occurred while sending your request.");
                        }
                    })
                    .finally(function() {
                        $submitBtn.prop('disabled', false).val(originalBtnText);
                    });
            });

            $('input[type="reset"]').click(function() {
                $('#ordersForm input[type="text"]').css({
                    'border-color': '',
                    'box-shadow': ''
                });
            });

        });
    </script>
</body>

</html>