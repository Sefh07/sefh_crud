<?php
require 'userrouter.php';

$customers = [];
try {
    $customerData = getCustomers();
    if (is_array($customerData)) {
        $customers = $customerData;
    } else {
        error_log("getCustomers() did not return an array.");
    }
} catch (Exception $e) {
    error_log("Error fetching customers: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMPLOYEE - ATTENDANCE</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="index1.css">
</head>

<body>
    <div class="container">
        <div class="page-actions">
            <a href="form.php" class="btn btn-back">Add Attendance</a>
        </div>

        <div class="table-container">
            <div>
                <h1>EMPLOYEE ATTENDANCE</h1>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>First name</th>
                        <th>Last name</th>
                        <th>Employee ID</th>
                        <th>EMPLOYEE POSITION</th>
                        <th>Date Attended</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($customers)): ?>
                        <?php foreach ($customers as $index => $row): ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><?= htmlspecialchars($row['Fname']) ?></td>
                                <td><?= htmlspecialchars($row['Lname']) ?></td>
                                <td><?= htmlspecialchars($row['employeeID']) ?></td>
                                <td><?= htmlspecialchars($row['position']) ?></td>
                                <td><?= $row['dateAttended'] ?></td>
                                <td>
                                    <a href="edit.php?id=<?= $row['id'] ?>" class="action-btn edit-btn">Edit</a>
                                    <a href="delete.php?id=<?= $row['id'] ?>"
                                        class="action-btn delete-btn"
                                        onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 20px; font-style: italic;">No customer records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>