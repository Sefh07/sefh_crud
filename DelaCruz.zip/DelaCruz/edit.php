<?php
require 'userrouter.php';

$id = null;
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $id = (int)$_GET['id'];
} else {
    die("Invalid or missing customer ID.");
}

$customer = null;
try {
    $customerData = getCustomerById($id);
    if ($customerData) {
        $customer = $customerData;
    } else {
        die("Customer with ID " . htmlspecialchars($id) . " not found.");
    }
} catch (Exception $e) {
    error_log("Error fetching customer ID " . $id . ": " . $e->getMessage());
    die("Could not load customer data. Please try again later.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee Attendance</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <link rel="stylesheet" href="edit1.css">
</head>

<body>
    <div class="form-container">
        <h2>Edit Employee Attendance</h2>
        <form id="customerform">
            <div>
                <label for="Fname">First Name</label>
                <input type="text" name="Fname" id="Fname" placeholder="First Name" value="<?= htmlspecialchars($customer['Fname']) ?>" required>
            </div>
            <div>
                <label for="Lname">Last Name</label>
                <input type="text" name="Lname" id="Lname" placeholder="Last Name" value="<?= htmlspecialchars($customer['Lname']) ?>" required>
            </div>
            <div>
                <label for="employeeID">Employee ID</label>
                <input type="text" name="employeeID" id="employeeID" placeholder="Employee ID" value="<?= htmlspecialchars($customer['employeeID']) ?>" required>
            </div>
            <div>
                <label for="position">Position</label>
                <input type="text" name="position" id="position" placeholder="Position" value="<?= htmlspecialchars($customer['position']) ?>" required>
            </div>
            <input type="hidden" name="id" id="id" value="<?= $id ?>">

            <div class="form-buttons">
                <input type="submit" value="Save" id="save" class="btn btn-submit">
                <a href="index.php" class="btn btn-cancel">Cancel</a>
            </div>
        </form>
    </div>

    <script>
        $(document).ready(function() {
            $('#customerform').submit(function(e) {
                e.preventDefault();

                let Fname = $('#Fname').val().trim();
                let Lname = $('#Lname').val().trim();
                let employeeID = $('#employeeID').val().trim();
                let position = $('#position').val().trim();
                let id = $('#id').val().trim();

                if (!Fname || !Lname || !employeeID || !position) {
                    alert("All fields are required!");
                    return;
                }

                const frm = new FormData();
                frm.append("method", "editCustomer");
                frm.append("Fname", Fname);
                frm.append("Lname", Lname);
                frm.append("employeeID", employeeID);
                frm.append("position", position);
                frm.append("id", id);

                axios.post("handler.php", frm)
                    .then(function(response) {
                        if (response.data && response.data.ret == 1) {
                            alert("Customer updated successfully!");
                            window.location.href = "index.php";
                        } else {
                            alert("Error updating customer: " + (response.data && response.data.msg ? response.data.msg : "Unknown error occurred."));
                        }
                    })
                    .catch(function(error) {
                        console.error("Request failed:", error);
                        if (error.response) {
                            console.error("Server Error Data:", error.response.data);
                            console.error("Server Error Status:", error.response.status);
                            alert(`Server Error ${error.response.status}: ${error.response.data.msg || 'Failed to process request.'}`);
                        } else if (error.request) {
                            console.error("No response received:", error.request);
                            alert("Could not connect to the server. Please check your network connection.");
                        } else {
                            console.error("Error setting up request:", error.message);
                            alert("An error occurred while sending your request.");
                        }
                    });
            });
        });
    </script>
</body>

</html>