<?php
    require_once 'dbcontroller.php';

    function saveCustomer($customer){
        $db = new DbController();
        
        if($db->getState() == true){
            $conn = $db->getDb();
            $stmt = $conn->prepare("INSERT INTO customer (Fname, Lname, employeeID, position) VALUES (:Fname, :Lname, :employeeID, :position)");
            $stmt->bindParam(':Fname', $customer['Fname']);
            $stmt->bindParam(':Lname', $customer['Lname']);
            $stmt->bindParam(':employeeID', $customer['employeeID']);
            $stmt->bindParam(':position', $customer['position']);
            $stmt->execute();
            return true;
        }else{
            return false;
        }

    }

    function editCustomers($customer){
        $db = new DbController();
        
        if($db->getState() == true){
            $conn = $db->getDb();
            $stmt = $conn->prepare("UPDATE customer SET Fname = :Fname, Lname = :Lname, employeeID = :employeeID, position = :position WHERE id = :id");
            $stmt->bindParam(':Fname', $customer['Fname']);
            $stmt->bindParam(':Lname', $customer['Lname']);
            $stmt->bindParam(':employeeID', $customer['employeeID']);
            $stmt->bindParam(':position', $customer['position']);
            $stmt->bindParam(':id', $customer['id']);
            $stmt->execute();
            return true;
        }else{
            return false;
        }
    }

    function getCustomers()
    {
        $db = new DbController();

        if ($db->getState() == true) {
            $conn = $db->getDb();
            $stmt = $conn->prepare("SELECT * FROM customer");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            return false;
        }
    }
    function getCustomerById($id){
        $db = new DbController();
        
        if($db->getState() == true){
            $conn = $db->getDb();
            $stmt = $conn->prepare("SELECT * FROM customer WHERE id = :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }else{
            return false;
        }
    }
    
    function updateCustomer($customer){
        $db = new DbController();
        
        if($db->getState() == true){
            $conn = $db->getDb();
            $stmt = $conn->prepare("UPDATE customer SET Fname = :Fname, Lname = :Lname, employeeID = :employeeID, position = :position WHERE id = :id");
            $stmt->bindParam(':Fname', $customer['Fname']);
            $stmt->bindParam(':Lname', $customer['Lname']);
            $stmt->bindParam(':employeeID', $customer['employeeID']);
            $stmt->bindParam(':position', $customer['position']);
            $stmt->bindParam(':id', $customer['id']);
            $stmt->execute();
            return true;
        }else{
            return false;
        }
    }
    function deleteCustomer($id){
        $db = new DbController();
        
        if($db->getState() == true){
            $conn = $db->getDb();
            $stmt = $conn->prepare("DELETE FROM customer WHERE id = :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return true;
        }else{
            return false;
        }
    }
?>

