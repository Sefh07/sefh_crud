<?php
require 'userrouter.php';
$id = $_GET['id'];
$customer = deleteCustomer($id);

if ($customer) {
    header("location: index.php");
}
else {
    echo "Error deleting record: " . mysqli_error($conn);
}
?>